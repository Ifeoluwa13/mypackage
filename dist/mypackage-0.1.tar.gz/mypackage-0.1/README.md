# mypackage
This library was created as an example of how to publish your own package.

# How to install
...